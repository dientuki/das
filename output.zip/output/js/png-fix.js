DD_belatedPNG.fix('.brochure a, .follow-us a, .mail-to a, .home a, .clients img');
//DD_belatedPNG.fix('.title h1, #right-sidebar, #left-sidebar .bg-bottom, #left-sidebar .bg-top');
//DD_belatedPNG.fix('#right-sidebar .title, .main-content .unsorted-list-title, .main-content .bg');
DD_belatedPNG.fix('.gallery-link figure');//, .main-content .bg');

