head.js('js/libs/jquery-1.6.2-min.js','js/das-js.js');
if (head.browser.ie) {if (parseInt(head.browser.version) <= 6) {head.js('js/png-fix-min.js')}}